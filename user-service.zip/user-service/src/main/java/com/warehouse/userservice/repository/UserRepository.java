package com.warehouse.userservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.warehouse.userservice.entity.Role;
import com.warehouse.userservice.entity.User;

public interface UserRepository
        extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    Optional<User> findByEmployeeCode(String employeeCode);

    boolean existsByEmail(String email);

    boolean existsByRole(Role role);

    boolean existsByEmployeeCode(String employeeCode);

    List<User> findByRole(Role role);

    List<User> findByWarehouseId(Long warehouseId);
}