package com.warehouse.userservice.service;

import java.util.List;

import com.warehouse.userservice.dto.InternalUserResponse;
import com.warehouse.userservice.dto.UserRequest;
import com.warehouse.userservice.dto.UserResponse;
import com.warehouse.userservice.entity.Role;

public interface UserService {

    UserResponse createUser(UserRequest request);

    List<UserResponse> getAllUsers();

    UserResponse getUserById(Long id);

    UserResponse updateUser(Long id, UserRequest request);

    List<UserResponse> getUsersByRole(Role role);

    List<UserResponse> getUsersByWarehouse(Long warehouseId);

    UserResponse assignWarehouse(Long id, Long warehouseId);

    UserResponse updateUserStatus(Long id, Boolean active);

    InternalUserResponse getInternalUserByEmail(String email);
}