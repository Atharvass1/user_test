package com.warehouse.userservice.entity;

public enum Role {

    ADMIN,
    MANAGER,
    WORKER
}