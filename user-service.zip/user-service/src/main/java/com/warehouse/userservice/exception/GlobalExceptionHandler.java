package com.warehouse.userservice.exception;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>>
            handleResourceNotFound(
                    ResourceNotFoundException exception) {

        return buildResponse(
                HttpStatus.NOT_FOUND,
                exception.getMessage());
    }

    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<Map<String, Object>>
            handleDuplicateResource(
                    DuplicateResourceException exception) {

        return buildResponse(
                HttpStatus.CONFLICT,
                exception.getMessage());
    }

    @ExceptionHandler(InvalidUserDataException.class)
    public ResponseEntity<Map<String, Object>>
            handleInvalidUserData(
                    InvalidUserDataException exception) {

        return buildResponse(
                HttpStatus.BAD_REQUEST,
                exception.getMessage());
    }

    @ExceptionHandler(ServiceCommunicationException.class)
    public ResponseEntity<Map<String, Object>>
            handleServiceCommunication(
                    ServiceCommunicationException exception) {

        return buildResponse(
                HttpStatus.SERVICE_UNAVAILABLE,
                exception.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>>
            handleValidation(
                    MethodArgumentNotValidException exception) {

        Map<String, String> validationErrors =
                new LinkedHashMap<>();

        exception.getBindingResult()
                .getFieldErrors()
                .forEach(error ->
                        validationErrors.put(
                                error.getField(),
                                error.getDefaultMessage()));

        Map<String, Object> responseBody =
                new LinkedHashMap<>();

        responseBody.put(
                "timestamp",
                LocalDateTime.now());
        responseBody.put(
                "status",
                HttpStatus.BAD_REQUEST.value());
        responseBody.put(
                "message",
                "Validation failed");
        responseBody.put(
                "errors",
                validationErrors);

        return new ResponseEntity<>(
                responseBody,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>>
            handleUnexpectedException(Exception exception) {

        return buildResponse(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "An unexpected error occurred");
    }

    private ResponseEntity<Map<String, Object>>
            buildResponse(
                    HttpStatus status,
                    String message) {

        Map<String, Object> responseBody =
                new LinkedHashMap<>();

        responseBody.put(
                "timestamp",
                LocalDateTime.now());
        responseBody.put(
                "status",
                status.value());
        responseBody.put(
                "message",
                message);

        return new ResponseEntity<>(
                responseBody,
                status);
    }
}