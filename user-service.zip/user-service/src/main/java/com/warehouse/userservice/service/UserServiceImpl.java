package com.warehouse.userservice.service;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.warehouse.userservice.client.WarehouseClient;
import com.warehouse.userservice.dto.InternalUserResponse;
import com.warehouse.userservice.dto.UserRequest;
import com.warehouse.userservice.dto.UserResponse;
import com.warehouse.userservice.dto.WarehouseDetailsResponse;
import com.warehouse.userservice.entity.Role;
import com.warehouse.userservice.entity.User;
import com.warehouse.userservice.exception.DuplicateResourceException;
import com.warehouse.userservice.exception.InvalidUserDataException;
import com.warehouse.userservice.exception.ResourceNotFoundException;
import com.warehouse.userservice.exception.ServiceCommunicationException;
import com.warehouse.userservice.repository.UserRepository;

import feign.FeignException;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final WarehouseClient warehouseClient;

    public UserServiceImpl(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            WarehouseClient warehouseClient) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.warehouseClient = warehouseClient;
    }

    @Override
    public UserResponse createUser(UserRequest request) {

        validateNewUser(request);

        User user = new User();

        user.setEmployeeCode(request.getEmployeeCode());
        user.setFullName(request.getFullName().trim());
        user.setEmail(normalizeEmail(request.getEmail()));
        user.setPassword(
                passwordEncoder.encode(request.getPassword()));
        user.setPhone(request.getPhone());
        user.setRole(request.getRole());
        user.setWarehouseId(request.getWarehouseId());
        user.setActive(true);
        user.setCreatedAt(LocalDateTime.now());

        User savedUser = userRepository.save(user);

        LOGGER.info(
                "User created successfully with ID: {} and role: {}",
                savedUser.getId(),
                savedUser.getRole());

        return convertToResponse(savedUser);
    }

    @Override
    public List<UserResponse> getAllUsers() {

        return userRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    @Override
    public UserResponse getUserById(Long id) {

        User user = findUser(id);

        return convertToResponse(user);
    }

    @Override
    public UserResponse updateUser(
            Long id,
            UserRequest request) {

        User existingUser = findUser(id);

        validateUpdatedUser(existingUser, request);

        existingUser.setEmployeeCode(
                request.getEmployeeCode());
        existingUser.setFullName(
                request.getFullName().trim());
        existingUser.setEmail(
                normalizeEmail(request.getEmail()));
        existingUser.setPhone(request.getPhone());
        existingUser.setRole(request.getRole());
        existingUser.setWarehouseId(
                request.getWarehouseId());

        if (request.getPassword() != null
                && !request.getPassword().isBlank()) {

            existingUser.setPassword(
                    passwordEncoder.encode(
                            request.getPassword()));
        }

        existingUser.setUpdatedAt(LocalDateTime.now());

        User updatedUser =
                userRepository.save(existingUser);

        LOGGER.info(
                "User updated successfully with ID: {}",
                updatedUser.getId());

        return convertToResponse(updatedUser);
    }

    @Override
    public List<UserResponse> getUsersByRole(Role role) {

        return userRepository.findByRole(role)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    @Override
    public List<UserResponse> getUsersByWarehouse(
            Long warehouseId) {

        validateWarehouse(warehouseId);

        return userRepository.findByWarehouseId(warehouseId)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    @Override
    public UserResponse assignWarehouse(
            Long id,
            Long warehouseId) {

        User user = findUser(id);

        if (user.getRole() == Role.ADMIN) {
            throw new InvalidUserDataException(
                    "Admin cannot be assigned to a warehouse");
        }

        validateWarehouse(warehouseId);

        user.setWarehouseId(warehouseId);
        user.setUpdatedAt(LocalDateTime.now());

        User updatedUser = userRepository.save(user);

        LOGGER.info(
                "Warehouse ID {} assigned to user ID {}",
                warehouseId,
                id);

        return convertToResponse(updatedUser);
    }

    @Override
    public UserResponse updateUserStatus(
            Long id,
            Boolean active) {

        if (active == null) {
            throw new InvalidUserDataException(
                    "Active status is required");
        }

        User user = findUser(id);

        if (user.getRole() == Role.ADMIN
                && Boolean.FALSE.equals(active)) {

            throw new InvalidUserDataException(
                    "The main Admin account cannot be deactivated");
        }

        user.setActive(active);
        user.setUpdatedAt(LocalDateTime.now());

        User updatedUser = userRepository.save(user);

        LOGGER.info(
                "User status updated to {} for user ID: {}",
                active,
                id);

        return convertToResponse(updatedUser);
    }

    @Override
    public InternalUserResponse getInternalUserByEmail(
            String email) {

        String normalizedEmail = normalizeEmail(email);

        User user = userRepository
                .findByEmail(normalizedEmail)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with email: "
                                        + normalizedEmail));

        return convertToInternalResponse(user);
    }

    private void validateNewUser(UserRequest request) {

        String normalizedEmail =
                normalizeEmail(request.getEmail());

        if (userRepository.existsByEmail(normalizedEmail)) {
            throw new DuplicateResourceException(
                    "Email is already registered");
        }

        if (request.getEmployeeCode() != null
                && !request.getEmployeeCode().isBlank()
                && userRepository.existsByEmployeeCode(
                        request.getEmployeeCode())) {

            throw new DuplicateResourceException(
                    "Employee code already exists");
        }

        if (request.getRole() == Role.ADMIN
                && userRepository.existsByRole(Role.ADMIN)) {

            throw new DuplicateResourceException(
                    "Only one Admin account is allowed");
        }

        validateRoleFields(request);
    }

    private void validateUpdatedUser(
            User existingUser,
            UserRequest request) {

        String normalizedEmail =
                normalizeEmail(request.getEmail());

        userRepository.findByEmail(normalizedEmail)
                .filter(user ->
                        !user.getId().equals(
                                existingUser.getId()))
                .ifPresent(user -> {
                    throw new DuplicateResourceException(
                            "Email is already registered");
                });

        validateDuplicateEmployeeCode(
                existingUser,
                request.getEmployeeCode());

        validateRoleFields(request);
    }

    private void validateDuplicateEmployeeCode(
            User existingUser,
            String employeeCode) {

        if (employeeCode == null
                || employeeCode.isBlank()) {
            return;
        }

        userRepository.findByEmployeeCode(employeeCode)
                .filter(user ->
                        !user.getId().equals(
                                existingUser.getId()))
                .ifPresent(user -> {
                    throw new DuplicateResourceException(
                            "Employee code already exists");
                });
    }

    private void validateRoleFields(UserRequest request) {

        if (request.getRole() == Role.ADMIN) {

            request.setEmployeeCode(null);
            request.setWarehouseId(null);
            return;
        }

        if (request.getEmployeeCode() == null
                || request.getEmployeeCode().isBlank()) {

            throw new InvalidUserDataException(
                    "Employee code is required "
                            + "for Manager and Worker");
        }

        if (request.getRole() == Role.WORKER) {

            if (request.getWarehouseId() == null) {
                throw new InvalidUserDataException(
                        "Warehouse assignment is required "
                                + "for Worker");
            }

            validateWarehouse(request.getWarehouseId());
        }

        if (request.getRole() == Role.MANAGER
                && request.getWarehouseId() != null) {

            validateWarehouse(request.getWarehouseId());
        }
    }

    private void validateWarehouse(Long warehouseId) {

        if (warehouseId == null || warehouseId <= 0) {
            throw new InvalidUserDataException(
                    "Enter a valid warehouse ID");
        }

        WarehouseDetailsResponse warehouse;

        try {
            warehouse =
                    warehouseClient.getWarehouseById(
                            warehouseId);

        } catch (FeignException.NotFound exception) {

            LOGGER.warn(
                    "Warehouse not found during assignment: {}",
                    warehouseId);

            throw new InvalidUserDataException(
                    "Warehouse not found with ID: "
                            + warehouseId);

        } catch (FeignException exception) {

            LOGGER.error(
                    "Warehouse Service call failed "
                            + "with status: {}",
                    exception.status());

            throw new ServiceCommunicationException(
                    "Unable to contact Warehouse Service");
        }

        if (!"ACTIVE".equalsIgnoreCase(
                warehouse.getStatus())) {

            throw new InvalidUserDataException(
                    "User cannot be assigned "
                            + "to an inactive warehouse");
        }
    }

    private User findUser(Long id) {

        return userRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with ID: "
                                        + id));
    }

    private String normalizeEmail(String email) {

        return email.trim().toLowerCase();
    }

    private UserResponse convertToResponse(User user) {

        UserResponse response = new UserResponse();

        response.setId(user.getId());
        response.setEmployeeCode(user.getEmployeeCode());
        response.setFullName(user.getFullName());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
        response.setRole(user.getRole());
        response.setWarehouseId(user.getWarehouseId());
        response.setActive(user.getActive());
        response.setCreatedAt(user.getCreatedAt());
        response.setUpdatedAt(user.getUpdatedAt());

        return response;
    }

    private InternalUserResponse convertToInternalResponse(
            User user) {

        InternalUserResponse response =
                new InternalUserResponse();

        response.setId(user.getId());
        response.setEmail(user.getEmail());
        response.setPassword(user.getPassword());
        response.setRole(user.getRole());
        response.setWarehouseId(user.getWarehouseId());
        response.setActive(user.getActive());

        return response;
    }
}