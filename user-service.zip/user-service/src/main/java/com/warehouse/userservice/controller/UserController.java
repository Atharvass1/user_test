package com.warehouse.userservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.warehouse.userservice.dto.InternalUserResponse;
import com.warehouse.userservice.dto.UserRequest;
import com.warehouse.userservice.dto.UserResponse;
import com.warehouse.userservice.entity.Role;
import com.warehouse.userservice.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<UserResponse> createUser(
            @Valid @RequestBody UserRequest request) {

        UserResponse response =
                userService.createUser(request);

        return new ResponseEntity<>(
                response,
                HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<UserResponse>> getAllUsers() {

        return ResponseEntity.ok(
                userService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUserById(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                userService.getUserById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserRequest request) {

        return ResponseEntity.ok(
                userService.updateUser(id, request));
    }

    @GetMapping("/role/{role}")
    public ResponseEntity<List<UserResponse>> getUsersByRole(
            @PathVariable Role role) {

        return ResponseEntity.ok(
                userService.getUsersByRole(role));
    }

    @GetMapping("/warehouse/{warehouseId}")
    public ResponseEntity<List<UserResponse>>
            getUsersByWarehouse(
                    @PathVariable Long warehouseId) {

        return ResponseEntity.ok(
                userService.getUsersByWarehouse(warehouseId));
    }

    @PatchMapping("/{id}/warehouse/{warehouseId}")
    public ResponseEntity<UserResponse> assignWarehouse(
            @PathVariable Long id,
            @PathVariable Long warehouseId) {

        return ResponseEntity.ok(
                userService.assignWarehouse(id, warehouseId));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<UserResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Boolean active) {

        return ResponseEntity.ok(
                userService.updateUserStatus(id, active));
    }

    @GetMapping("/internal/email/{email}")
    public ResponseEntity<InternalUserResponse>
            getInternalUserByEmail(
                    @PathVariable String email) {

        return ResponseEntity.ok(
                userService.getInternalUserByEmail(email));
    }
}