package com.warehouse.userservice.exception;

public class ServiceCommunicationException
        extends RuntimeException {

    public ServiceCommunicationException(String message) {
        super(message);
    }
}