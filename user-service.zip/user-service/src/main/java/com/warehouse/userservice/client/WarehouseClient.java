package com.warehouse.userservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.warehouse.userservice.dto.WarehouseDetailsResponse;

@FeignClient(name = "WAREHOUSE-SERVICE")
public interface WarehouseClient {

    @GetMapping("/warehouses/{warehouseId}")
    WarehouseDetailsResponse getWarehouseById(
            @PathVariable("warehouseId") Long warehouseId);
}